package general;

import archivos.*;

public class Principal {
	
	public static void main(String args[]){
		Archivo.crear();
		FrmPrincipal frm = new FrmPrincipal();
		frm.setVisible(true);
	}

}
