package general;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.JButton;
import javax.swing.JTable;
import javax.swing.JScrollPane;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import javax.swing.DefaultComboBoxModel;

import archivos.Archivo;

import java.util.ArrayList;
import java.util.Vector;

import entidades.*;
import archivos.*;
import utilidades.*
;
public class FrmMantenimientoPersona extends JFrame {

	private JPanel contentPane;
	private JTextField tfDescripcion;
	private JTable tResultado;
	private JComboBox cbTipo;

	

	/**
	 * Create the frame.
	 */
	public FrmMantenimientoPersona() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		tfDescripcion = new JTextField();
		tfDescripcion.setBounds(6, 6, 185, 28);
		contentPane.add(tfDescripcion);
		tfDescripcion.setColumns(10);
		tfDescripcion.setEditable(false);
		
		cbTipo = new JComboBox();
		cbTipo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				actualizarEstadoDescripcion();
			}
		});
		cbTipo.setModel(new DefaultComboBoxModel(new String[] {"TODOS", "NOMBRES", "APELLIDOS", "EDAD"}));
		cbTipo.setBounds(191, 8, 141, 27);
		contentPane.add(cbTipo);
		
		JButton bConsultar = new JButton("Consultar");
		bConsultar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				consultarPersonas();
			}
		});
		bConsultar.setBounds(327, 7, 117, 29);
		contentPane.add(bConsultar);
		
		JButton bIngresar = new JButton("Ingresar");
		bIngresar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ingresarPersona();
			}
		});
		bIngresar.setBounds(6, 243, 117, 29);
		contentPane.add(bIngresar);
		
		JButton bEditar = new JButton("Editar");
		bEditar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				editarPersona();
			}
		});
		bEditar.setBounds(162, 243, 117, 29);
		contentPane.add(bEditar);
		
		JButton bEliminar = new JButton("Eliminar");
		bEliminar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				eliminarPersonas();
			}
		});
		bEliminar.setBounds(313, 243, 117, 29);
		contentPane.add(bEliminar);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(16, 49, 414, 155);
		contentPane.add(scrollPane);
		
		tResultado = new JTable();
		tResultado.setModel(new DefaultTableModel(
				null,
				new String[]{	"Cédula",
								"Nombres",
								"Apellidos",
								"Edad"}));
		scrollPane.setViewportView(tResultado);
	}
	
	private void ingresarPersona(){
		FrmIngresoPersona f = new FrmIngresoPersona();
		f.setVisible(true);
	}
	
	public void consultarPersonas(){
		if(formularioConsultaValido()){
			String descripcion = tfDescripcion.getText();
			String tipo = cbTipo.getSelectedItem().toString();
			
			try{
				ArrayList<Persona> registros = Archivo.obtener_registros();
				DefaultTableModel m =(DefaultTableModel)tResultado.getModel();
				m.setRowCount(0);
				if(tipo.equals("TODOS")){					
					for(int i=0;i<registros.size();i++){
						Persona tmp = registros.get(i);
						Vector fila = new Vector();
						fila.add(tmp.getCedula());
						fila.add(tmp.getNombres());
						fila.add(tmp.getApellidos());
						fila.add(tmp.getEdad());										
						m.addRow(fila);
					}					
				}else if(tipo.equals("NOMBRES")){
					for(int i=0;i<registros.size();i++){
						Persona tmp = registros.get(i);
						if(tmp.getNombres().toUpperCase().contains(descripcion.toUpperCase())){
							Vector fila = new Vector();
							fila.add(tmp.getCedula());
							fila.add(tmp.getNombres());
							fila.add(tmp.getApellidos());
							fila.add(tmp.getEdad());										
							m.addRow(fila);						
						}												
					}					
				}else if(tipo.equals("APELLIDOS")){
					for(int i=0;i<registros.size();i++){
						Persona tmp = registros.get(i);
						if(tmp.getApellidos().toUpperCase().contains(descripcion.toUpperCase())){
							Vector fila = new Vector();
							fila.add(tmp.getCedula());
							fila.add(tmp.getNombres());
							fila.add(tmp.getApellidos());
							fila.add(tmp.getEdad());										
							m.addRow(fila);						
						}												
					}					
				}else if(tipo.equals("EDAD")){
					for(int i=0;i<registros.size();i++){
						Persona tmp = registros.get(i);
						if(Integer.toString(tmp.getEdad()).contains(descripcion)){						
					//	if(tmp.getEdad()==Integer.parseInt(descripcion)){		
							Vector fila = new Vector();
							fila.add(tmp.getCedula());
							fila.add(tmp.getNombres());
							fila.add(tmp.getApellidos());
							fila.add(tmp.getEdad());										
							m.addRow(fila);						
						}												
					}					
				}								
			}catch(Exception e){
				JOptionPane.showMessageDialog(this,"Ocurrió un error al consultar el archivo","Error",JOptionPane.ERROR_MESSAGE);
			}						
		}
	}
	
	private boolean formularioConsultaValido(){
		String descripcion = tfDescripcion.getText();
		String tipo = cbTipo.getSelectedItem().toString();
		if(!tipo.equals("TODOS") && descripcion.equals("")){
			JOptionPane.showMessageDialog(this,"Debe indicar un valor en la descripción","Validación",JOptionPane.ERROR_MESSAGE);
			return false;
		}
		if(tipo.equals("EDAD")){
			try{
				Integer.parseInt(descripcion);
			}catch(Exception e){
				JOptionPane.showMessageDialog(this,"La edad debe ser un número","Validación",JOptionPane.ERROR_MESSAGE);
				return false;
			}
		}
		
		
		return true;
	}
	
	private boolean seleccionEdicionValida(){
		int nfilas = tResultado.getSelectedRowCount();
		if(nfilas!=1){
			JOptionPane.showMessageDialog(this,"Debe seleccionar una fila para editar","Edición",JOptionPane.ERROR_MESSAGE);
			return false;
		}
		return true;
	}
	
	private void editarPersona(){
		if(seleccionEdicionValida()){
			int fila = tResultado.getSelectedRow();
			String cedula = tResultado.getValueAt(fila,0).toString();
			try{
				FrmEdicionPersona frm = new FrmEdicionPersona(cedula,this);
				frm.setVisible(true);
			}catch(Exception e){}				
		}		
	}
	
	private void actualizarEstadoDescripcion(){
		String tipo = String.valueOf(cbTipo.getSelectedItem());
		if(tipo.equals("TODOS")){
			tfDescripcion.setEditable(false);
		}else{
			tfDescripcion.setEditable(true);
		}
		tfDescripcion.setText(null);
	}
	
	private void eliminarPersonas(){
		if(seleccionEliminacionValida()){
			int fila = tResultado.getSelectedRow();
			String cedula = tResultado.getValueAt(fila,0).toString();
			try{
				ArrayList<Persona> personas = Archivo.obtener_registros();
				personas.remove(Busqueda.buscarPersonaPorCedula(personas, cedula));
				if(Archivo.actualizar_registros(personas)){
					JOptionPane.showMessageDialog(this,"Se realizó la eliminación con éxito", "Eliminación", JOptionPane.INFORMATION_MESSAGE);
					consultarPersonas();
				}else{
					JOptionPane.showMessageDialog(this,"Ocurrió un error en la eliminación", "Eliminación", JOptionPane.ERROR_MESSAGE);
				}
			}catch(Exception e){
				JOptionPane.showMessageDialog(this,"Ocurrió un error en la eliminación", "Eliminación", JOptionPane.ERROR_MESSAGE);
			}
		}
	}
	
	private boolean seleccionEliminacionValida(){
		if(tResultado.getSelectedRowCount()<=0){
			JOptionPane.showMessageDialog(this,"Debe seleccionar por lo menos un registro a eliminar","Eliminación",JOptionPane.ERROR_MESSAGE);
			return false;
		}
		return true;
	}
}
