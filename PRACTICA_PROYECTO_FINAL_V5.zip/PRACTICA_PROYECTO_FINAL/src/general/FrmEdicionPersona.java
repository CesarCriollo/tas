package general;

import java.awt.BorderLayout;
import java.util.ArrayList;

import entidades.*;
import archivos.*;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;

import utilidades.Busqueda;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class FrmEdicionPersona extends JFrame {

	private JPanel contentPane;
	private JTextField tfCedula;
	private JTextField tfNombres;
	private JTextField tfApellidos;
	private JTextField tfEdad;
	private FrmMantenimientoPersona frm;

	

	/**
	 * Create the frame.
	 */
	public FrmEdicionPersona(String cedula,FrmMantenimientoPersona frm) throws Exception{
		this.frm = frm;
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lCedula = new JLabel("Cédula:");
		lCedula.setBounds(57, 32, 61, 16);
		contentPane.add(lCedula);
		
		JLabel lNombres = new JLabel("Nombres:");
		lNombres.setBounds(57, 66, 61, 16);
		contentPane.add(lNombres);
		
		JLabel lApellidos = new JLabel("Apellidos:");
		lApellidos.setBounds(57, 104, 77, 16);
		contentPane.add(lApellidos);
		
		JLabel lEdad = new JLabel("Edad:");
		lEdad.setBounds(57, 140, 61, 16);
		contentPane.add(lEdad);
		
		tfCedula = new JTextField();
		tfCedula.setEditable(false);
		tfCedula.setBounds(162, 26, 223, 28);
		contentPane.add(tfCedula);
		tfCedula.setColumns(10);
		
		tfNombres = new JTextField();
		tfNombres.setBounds(162, 60, 223, 28);
		contentPane.add(tfNombres);
		tfNombres.setColumns(10);
		
		tfApellidos = new JTextField();
		tfApellidos.setBounds(162, 98, 223, 28);
		contentPane.add(tfApellidos);
		tfApellidos.setColumns(10);
		
		tfEdad = new JTextField();
		tfEdad.setBounds(162, 134, 51, 28);
		contentPane.add(tfEdad);
		tfEdad.setColumns(10);
		
		JButton bGuardar = new JButton("Guardar");
		bGuardar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				editarPersona();
			}
		});
		bGuardar.setBounds(107, 196, 117, 29);
		contentPane.add(bGuardar);
		
		JButton bLimpiar = new JButton("Limpiar");
		bLimpiar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				limpiarFormulario();
			}
		});
		bLimpiar.setBounds(234, 196, 117, 29);
		contentPane.add(bLimpiar);
		
		
		try{
			ArrayList<Persona> personas = Archivo.obtener_registros();
			Persona p =personas.get(Busqueda.buscarPersonaPorCedula(personas,cedula));
			tfCedula.setText(cedula);
			tfNombres.setText(p.getNombres());
			tfApellidos.setText(p.getApellidos());
			tfEdad.setText(Integer.toString(p.getEdad()));
		}catch(Exception e){
			JOptionPane.showMessageDialog(this, "Ocurrió un error al consultar en el archivo", "Edición",JOptionPane.ERROR_MESSAGE);
			throw e;
		}
	}
	
	public void limpiarFormulario(){
		tfNombres.setText("");
		tfApellidos.setText("");
		tfEdad.setText("");
	}
	
	public void editarPersona(){
		if(formularioValido()){
			String cedula = tfCedula.getText();
			String nombres = tfNombres.getText();
			String apellidos = tfApellidos.getText();
			int edad = Integer.parseInt(tfEdad.getText());
			Persona p = new Persona(cedula,nombres,apellidos,edad);
			if(Archivo.actualizar_registro(p)){
				JOptionPane.showMessageDialog(this,
				"Se editó correctamente la información de la persona",
				"Edición de Información",
				JOptionPane.INFORMATION_MESSAGE);
				frm.consultarPersonas();
				this.dispose();
			}else{
				JOptionPane.showMessageDialog(this,
				"Ocurrió un error en la edición",
				"Edición de Información",
				JOptionPane.ERROR_MESSAGE);
			}
		}
	}
	
	public boolean formularioValido(){
		if(	tfCedula.getText().equals("") ||
			tfNombres.getText().equals("") ||
			tfApellidos.getText().equals("") ||
			tfEdad.getText().equals("")){
			JOptionPane.showMessageDialog(this,"Faltan campos por llenar","Validación",JOptionPane.ERROR_MESSAGE);
			return false;
		}
		
		try{
			Integer.parseInt(tfEdad.getText());
		}catch(Exception e){
			JOptionPane.showMessageDialog(this,"La edad debe ser un número","Validación",JOptionPane.ERROR_MESSAGE);
			return false;
		}

		return true;
	}
}
