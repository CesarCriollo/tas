package general;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class FrmPrincipal extends JFrame {

	private JPanel contentPane;

	
	/**
	 * Create the frame.
	 */
	public FrmPrincipal() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		
		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		
		JMenu mInicio = new JMenu("Inicio");
		menuBar.add(mInicio);
		
		JMenuItem miSalir = new JMenuItem("Salir");
		miSalir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				salir();
			}
		});
		mInicio.add(miSalir);
		
		JMenu mMantenimiento = new JMenu("Mantenimiento");
		menuBar.add(mMantenimiento);
		
		JMenuItem miPersona = new JMenuItem("Persona");
		miPersona.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				mantenimientoPersona();
			}
		});
		mMantenimiento.add(miPersona);
		
		JMenu mAcercaDe = new JMenu("Acerca de..");
		menuBar.add(mAcercaDe);
		
		JMenuItem miIntegrantes = new JMenuItem("Integrantes");
		mAcercaDe.add(miIntegrantes);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
	}
	
	private void salir(){
		System.out.println("salir...");
		System.exit(0);
	}
	
	private void mantenimientoPersona(){
		FrmMantenimientoPersona f = new FrmMantenimientoPersona();
		f.setVisible(true);
	}

}
