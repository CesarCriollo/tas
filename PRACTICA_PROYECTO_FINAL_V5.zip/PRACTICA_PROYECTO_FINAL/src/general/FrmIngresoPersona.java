package general;

import java.awt.BorderLayout;
import java.util.ArrayList;

import entidades.*;
import archivos.*;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;

import utilidades.Validacion;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class FrmIngresoPersona extends JFrame {

	private JPanel contentPane;
	private JTextField tfCedula;
	private JTextField tfNombres;
	private JTextField tfApellidos;
	private JTextField tfEdad;

	

	/**
	 * Create the frame.
	 */
	public FrmIngresoPersona() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lCedula = new JLabel("Cédula:");
		lCedula.setBounds(57, 32, 61, 16);
		contentPane.add(lCedula);
		
		JLabel lNombres = new JLabel("Nombres:");
		lNombres.setBounds(57, 66, 61, 16);
		contentPane.add(lNombres);
		
		JLabel lApellidos = new JLabel("Apellidos:");
		lApellidos.setBounds(57, 104, 77, 16);
		contentPane.add(lApellidos);
		
		JLabel lEdad = new JLabel("Edad:");
		lEdad.setBounds(57, 140, 61, 16);
		contentPane.add(lEdad);
		
		tfCedula = new JTextField();
		tfCedula.setBounds(162, 26, 223, 28);
		contentPane.add(tfCedula);
		tfCedula.setColumns(10);
		
		tfNombres = new JTextField();
		tfNombres.setBounds(162, 60, 223, 28);
		contentPane.add(tfNombres);
		tfNombres.setColumns(10);
		
		tfApellidos = new JTextField();
		tfApellidos.setBounds(162, 98, 223, 28);
		contentPane.add(tfApellidos);
		tfApellidos.setColumns(10);
		
		tfEdad = new JTextField();
		tfEdad.setBounds(162, 134, 51, 28);
		contentPane.add(tfEdad);
		tfEdad.setColumns(10);
		
		JButton bIngresar = new JButton("Ingresar");
		bIngresar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ingresarPersona();
			}
		});
		bIngresar.setBounds(107, 196, 117, 29);
		contentPane.add(bIngresar);
		
		JButton bLimpiar = new JButton("Limpiar");
		bLimpiar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				limpiarFormulario();
			}
		});
		bLimpiar.setBounds(234, 196, 117, 29);
		contentPane.add(bLimpiar);
	}
	
	public void limpiarFormulario(){
		tfCedula.setText("");
		tfNombres.setText("");
		tfApellidos.setText("");
		tfEdad.setText("");
	}
	
	public void ingresarPersona(){
		if(formularioValido()){
			String cedula = tfCedula.getText();
			String nombres = tfNombres.getText();
			String apellidos = tfApellidos.getText();
			int edad = Integer.parseInt(tfEdad.getText());
			Persona p = new Persona(cedula,nombres,apellidos,edad);
			if(Archivo.insertar_registro(p)){
				JOptionPane.showMessageDialog(this,
				"Se ingresó correctamente la información de la persona",
				"Ingreso de Información",
				JOptionPane.INFORMATION_MESSAGE);
				limpiarFormulario();
			}else{
				JOptionPane.showMessageDialog(this,
				"Ocurrió un error en el ingreso",
				"Ingreso de Información",
				JOptionPane.ERROR_MESSAGE);
			}
		}
	}
	
	public boolean formularioValido(){
		if(	tfCedula.getText().equals("") ||
			tfNombres.getText().equals("") ||
			tfApellidos.getText().equals("") ||
			tfEdad.getText().equals("")){
			JOptionPane.showMessageDialog(this,"Faltan campos por llenar","Validación",JOptionPane.ERROR_MESSAGE);
			return false;
		}
		
		try{
			ArrayList<Persona> personas = Archivo.obtener_registros();
			if(Validacion.verificarDuplicidadCedula(personas, tfCedula.getText())){
				JOptionPane.showMessageDialog(this,"La cédula ya se encuentra registrada", "Validación", JOptionPane.ERROR_MESSAGE);	
				return false;
			}
		}catch(Exception e){}
		
		try{
			Integer.parseInt(tfEdad.getText());
		}catch(Exception e){
			JOptionPane.showMessageDialog(this,"La edad debe ser un número","Validación",JOptionPane.ERROR_MESSAGE);
			return false;
		}

		return true;
	}
}
