/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package utilidades;

import entidades.Persona;
import java.util.ArrayList;

/**
 *
 * @author vr
 */
public class Validacion {
    
    public static boolean verificarDuplicidadCedula(ArrayList<Persona> personas,String cedula){
        
        for(int i=0;i<personas.size();i++){                        
            if(personas.get(i).getCedula().equalsIgnoreCase(cedula))
                return true;        
        }
        return false;
    }    
    
    public static int existePersona(ArrayList<Persona> personas,Persona p){        
        for(int i=0;i<personas.size();i++){
            Persona p2 = personas.get(i);
            if(p.getCedula().equals(p2.getCedula())){                
                return i;
            }        
        }
        return -1;    
    }
    
}
