/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package utilidades;

import java.util.Scanner;
/**
 *
 * @author Laboratorio 5
 */
public class Ingreso {
    
    public static int leerNumero(String mensaje){
        System.out.print(mensaje);
        Scanner sc = new Scanner(System.in);
        int numero = sc.nextInt();
        return numero;
    }
    
    public static String leerTexto(String mensaje){
        System.out.print(mensaje);
        Scanner sc = new Scanner(System.in);
        String texto = sc.nextLine();
        return texto;
    }
    
}
